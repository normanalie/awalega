#include <stdio.h>
#include <stdlib.h>


#include "graphic_lib/graphic_lib.h"
#include "graphic_lib/shapes.h"
#include "audio_lib/audio_lib.h"



int main(void)
{
    graphic_init();
    create_window(1280, 720, "Awaléga");

    Image Images;
    init_Images(&Images);
    Rectangle Rectangles;
    init_Rectangle(&Rectangles);

    present_image(Images.background.menu,Rectangles.bg.menu);
    present_image(Images.button.play,Rectangles.button.play);
    present_image(Images.button.leaderboard,Rectangles.button.leaderboard);
    present_image(Images.button.about,Rectangles.button.about);
    present_image(Images.button.leave,Rectangles.button.leave);

    /*----------------------------------*/
    openAudio();
    openSoundChannels(NUM_CHANNELS);

    audio Audio;
    loadAllMusics(&Audio);
    loadAllSounds(&Audio);
    /*----------------------------------*/
    playAudio(MUSIC_STRUCT.music1, REP_INF);
    int volume = HALF_MAX_VOLUME-AUDIO_INCREMENT;
    /*----------------------------------*/

    char quit = 0;
    SDL_Event event;
    while (!quit)
    {
        graphic_update();
        event = graphic_get_event();

        switch (event.type)
        {
        /*----------------------------------*/       
        case SDL_KEYDOWN:
            playSound(SOUND_STRUCT.typing.numChannel, SOUND_STRUCT.typing.sound, 0); 
        switch(event.SDL_KEYBOARD)
        {
            /*----------------------------------*/ //phase de test
            case SDLK_p: 
                pauseAudio();
            break;

            case SDLK_r:
                rewindAudio();
            break;

            case SDLK_o:
                playAudioAgain(MUSIC_STRUCT.music1, REP_INF); 
            break;

            case SDLK_d: 
                audioVolumeUpdate(&volume, -AUDIO_INCREMENT);
            break;

            case SDLK_u:
                audioVolumeUpdate(&volume, AUDIO_INCREMENT);
            break;

            case SDLK_m:
                if(volume != 0)
                    audioVolumeMuteUnmute(&volume, -AUDIO_INCREMENT);
                else
                {
                    audioVolumeMuteUnmute(&volume, AUDIO_INCREMENT);
                }
            break;

            case SDLK_0:
                playAudio(MUSIC_STRUCT.menuMusic, REP_INF);
            break;

            case SDLK_1:
                playAudio(MUSIC_STRUCT.inGameMusic, REP_INF);
            break;

            case SDLK_2:
                playAudio(MUSIC_STRUCT.leaderboardMusic, REP_INF);
            break;

            case SDLK_3:
                playAudio(MUSIC_STRUCT.aboutMusic, REP_INF);
            break;

            case SDLK_4:
                playSound(SOUND_STRUCT.mouseClick.numChannel, SOUND_STRUCT.mouseClick.sound, REP_ONCE);
            break;

            case SDLK_5: 
                playSound(SOUND_STRUCT.victory.numChannel, SOUND_STRUCT.victory.sound, REP_ONCE);
            break;

            case SDLK_6: 
                playSound(SOUND_STRUCT.defeat.numChannel, SOUND_STRUCT.defeat.sound, REP_ONCE);
            break;

            case SDLK_7: 
                playSound(SOUND_STRUCT.loading.numChannel, SOUND_STRUCT.loading.sound, REP_ONCE);
            break;

            case SDLK_8: 
                playSound(SOUND_STRUCT.beanDeposit.numChannel, SOUND_STRUCT.beanDeposit.sound, REP_ONCE);
            break;

            case SDLK_9:
                playSound(SOUND_STRUCT.buzzWrongAction.numChannel, SOUND_STRUCT.buzzWrongAction.sound, REP_ONCE);
            break;

            default:
                continue;
        }
        //playSound(SOUND_STRUCT.typing.numChannel, SOUND_STRUCT.typing.sound, 0);
        break;

        case SDL_MOUSEBUTTONDOWN:
        
        switch(event.SDL_MOUSE)
        {
            case SDL_BUTTON_LEFT:
                playSound(SOUND_STRUCT.mouseClick.numChannel, SOUND_STRUCT.mouseClick.sound, REP_ONCE);
            break;

            case SDL_BUTTON_RIGHT:
                playSound(SOUND_STRUCT.buzzWrongAction.numChannel, SOUND_STRUCT.buzzWrongAction.sound, REP_ONCE);
            break;
        }
        break;
        /*----------------------------------*/
        case SDL_QUIT:
            quit = 1;
            break;
        }

    }
    /*----------------------------------*/
    freeAllMusics(&Audio);
    freeAllSounds(&Audio);
    closeAudio();
    /*----------------------------------*/
    destroy_Images(&Images);
    destroy_window();

    return 0;
}