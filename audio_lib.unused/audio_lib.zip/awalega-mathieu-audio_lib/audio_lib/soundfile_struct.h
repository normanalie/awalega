#ifndef SOUNDFILESTRUCTH
#define SOUNDFILESTRUCTH

#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <stdlib.h> 
//#include "../../../../../../usr/include/SDL2/SDL_mixer.h"


typedef struct
{
    Mix_Music* music1;
    Mix_Music* music2;
    Mix_Music* menuMusic;
    Mix_Music* inGameMusic;
    Mix_Music* leaderboardMusic;
    Mix_Music* aboutMusic;
}music;

typedef struct //sound components
{
    Mix_Chunk* sound;
    int numChannel;
}sound_comp;



typedef struct 
{
    sound_comp mouseClick;
    sound_comp victory;
    sound_comp defeat;
    sound_comp loading;
    sound_comp beanDeposit;
    sound_comp buzzWrongAction;
    sound_comp typing;
}sound;

typedef struct 
{
    music musicSection;
    sound soundSection;
}audio;
//audio Audio;




 #endif 